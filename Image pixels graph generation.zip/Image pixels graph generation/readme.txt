first import openCv.jar in the Task1 class 
 then import jfree-chart-demo.jar in fullyFinal class
remember both must be done on differnt machines 
othervise it will effect the execution of the program 
